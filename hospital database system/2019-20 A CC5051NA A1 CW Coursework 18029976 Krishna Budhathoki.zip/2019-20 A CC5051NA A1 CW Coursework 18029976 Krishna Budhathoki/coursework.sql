SQL> INSERT INTO Patient VALUES ('P1','John','06-JAN-00','no','Male', 19, '','new');

1 row created.

SQL> INSERT INTO Patient VALUES ('P2','Max','08-FEB-97' ,'no','Male',22, '','new');

1 row created.

SQL> INSERT INTO Patient VALUES ('P3','Tom','01-OCT-89' ,'no', 'Male', 30, '','new');

1 row created.

SQL> INSERT INTO Patient VALUES ('P4','Jim','01-SEP-01','no','Male' ,18, '','regular');

1 row created.

SQL> INSERT INTO Patient VALUES ('P5','Natalia','05-NOV-65','no','Female',54, '','new');

1 row created.

SQL> INSERT INTO Patient VALUES ('P6','Pam','06-AUG-79' ,'no','Female' ,40, '','new');

1 row created.

SQL> INSERT INTO Patient VALUES ('P7','Andy','18-JUN-92' ,'yes','Male',27, 'S11','regular');

1 row created.

SQL> 
SQL> 
SQL> INSERT INTO  Address VALUES ('A1','Nepal','Province no.3','Kathmandu',139,'Jyatha Street');

1 row created.

SQL> INSERT INTO  Address VALUES ('A2','Nepal','Province no.3','Hetauda',4,'Hetauda City College');

1 row created.

SQL> INSERT INTO  Address VALUES ('A3','Nepal','Province no.3','Dolakha',21,'Kalinchok');

1 row created.

SQL> INSERT INTO  Address VALUES ('A4','Nepal','Province no.2','Birgunj',45,'Shankaracharya Gate');

1 row created.

SQL> INSERT INTO  Address VALUES ('A5','Nepal','Province no.1','Damak',65,'Damak Hospital');

1 row created.

SQL> INSERT INTO  Address VALUES ('A6','Nepal','Province no.5','Butwal',39,'Siddha Baba Temple');

1 row created.

SQL> INSERT INTO  Address VALUES ('A7','Nepal','Gandaki Pradesh','Pokhara',150,'Phewa Tal');

1 row created.

SQL> 
SQL> 
SQL> INSERT INTO Contact VALUES ('C1',9813778955,981378755,'john@gmail.com',22228888);

1 row created.

SQL> INSERT INTO Contact VALUES ('C2',9814798755,984178757,'max@gmail.com',12345868);

1 row created.

SQL> INSERT INTO Contact VALUES ('C3',9841768955,981778455,'tom@gmail.com',45225868);

1 row created.

SQL> INSERT INTO Contact VALUES ('C4',9840978955,982378755,'Jim@gmail.com',78225868);

1 row created.

SQL> INSERT INTO Contact VALUES ('C5',9815678555,981568755,'Natalia@gmail.com',22228888);

1 row created.

SQL> INSERT INTO Contact VALUES ('C6',9818756955,981678555,'Pam@gmail.com',56228888);

1 row created.

SQL> INSERT INTO Contact VALUES ('C7',9819778855,986378755,'Andy@gmail.com',67228888);

1 row created.

SQL> 
SQL> 
SQL> INSERT INTO Contact_info VALUES('P1','A1','C1');

1 row created.

SQL> INSERT INTO Contact_info VALUES('P2','A2','C2');

1 row created.

SQL> INSERT INTO Contact_info VALUES('P3','A3','C3');

1 row created.

SQL> INSERT INTO Contact_info VALUES('P4','A4','C4');

1 row created.

SQL> INSERT INTO Contact_info VALUES('P5','A5','C5');

1 row created.

SQL> INSERT INTO Contact_info VALUES('P6','A6','C6');

1 row created.

SQL> INSERT INTO Contact_info VALUES('P7','A7','C7');

1 row created.

SQL> 
SQL> INSERT INTO Ward VALUES('W1','Pediatrics',1);

1 row created.

SQL> INSERT INTO Ward VALUES('W2','Geriatrics',2);

1 row created.

SQL> INSERT INTO Ward VALUES('W3','Maternity',5);

1 row created.

SQL> INSERT INTO Ward VALUES('W4','Endoscopy',4);

1 row created.

SQL> INSERT INTO Ward VALUES('W5','Therapy',2);

1 row created.

SQL> INSERT INTO Ward VALUES('W6','Cardiology',2);

1 row created.

SQL> INSERT INTO Ward VALUES('W7','ENT',1);

1 row created.

SQL> INSERT INTO Ward VALUES('W8','Emergency',1);

1 row created.

SQL> 
SQL> 
SQL> 
SQL> INSERT INTO treatment VALUES('T1','Acute sinusitis','Vaccine therapy');

1 row created.

SQL> INSERT INTO treatment VALUES('T2','Weight Loss','health regime');

1 row created.

SQL> INSERT INTO treatment VALUES('T3','child healthcare','consultant');

1 row created.

SQL> INSERT INTO treatment VALUES('T4','Gastrointestinal tract','stomach');

1 row created.

SQL> INSERT INTO treatment VALUES('T5','exercise routine','heart disease');

1 row created.

SQL> INSERT INTO treatment VALUES('T6','heart','artery block');

1 row created.

SQL> INSERT INTO treatment VALUES('T7','ear','ear wax');

1 row created.

SQL> INSERT INTO treatment VALUES('T8','Emergency','Emergency');

1 row created.

SQL> 
SQL> INSERT INTO bill VALUES('B1','16-JAN-19',2000,'Cash');

1 row created.

SQL> INSERT INTO bill VALUES('B2','9-SEP-19',1000,'Cash');

1 row created.

SQL> INSERT INTO bill VALUES('B3','14-OCT-19',1000,'Cash');

1 row created.

SQL> INSERT INTO bill VALUES('B4','8-SEP-19',2000,'Cash');

1 row created.

SQL> INSERT INTO bill VALUES('B5','16-OCT-19',2000,'Cash');

1 row created.

SQL> INSERT INTO bill VALUES('B6','17-FEB-19',2000,'Cash');

1 row created.

SQL> INSERT INTO bill VALUES('B7','11-MAR-19',2000,'E-Cash');

1 row created.

SQL> INSERT INTO bill VALUES('B8','11-MAR-19',2000,'E-Cash');

1 row created.

SQL> 
SQL> 
SQL> INSERT INTO appointment VALUES('A1','15-JAN-19','10:30 AM','W1','T1','B1');

1 row created.

SQL> INSERT INTO appointment VALUES('A2','8-SEP-19','11:30 AM','W2','T2','B2');

1 row created.

SQL> INSERT INTO appointment VALUES('A3','13-OCT-19','12:30 AM','W3','T3','B3');

1 row created.

SQL> INSERT INTO appointment VALUES('A4','7-SEP-19','10:00 AM','W4','T4','B4');

1 row created.

SQL> INSERT INTO appointment VALUES('A5','15-OCT-19','1:30 PM','W5','T5','B5');

1 row created.

SQL> INSERT INTO appointment VALUES('A6','16-FEB-19','10:30 AM','W6','T6','B6');

1 row created.

SQL> INSERT INTO appointment VALUES('A7','10-MAR-19','10:30 AM','W7','T7','B7');

1 row created.

SQL> INSERT INTO appointment VALUES('A8','11-MAR-19','10:35 AM','W8','T8','B8');

1 row created.

SQL> 
SQL> 
SQL> 
SQL> 
SQL> 
SQL> INSERT INTO staff VALUES ('S1','Prashant','03-JAN-93','Doctor', 2000,'children','yes');

1 row created.

SQL> INSERT INTO staff VALUES ('S2','Kiran','04-FEB-92','Doctor', 3000,'Old-aged','yes');

1 row created.

SQL> INSERT INTO staff VALUES ('S8','Preeti','15-FEB-97','Nurse', 1000,'Old-aged','yes');

1 row created.

SQL> INSERT INTO staff VALUES ('S3','Ayuesh','17-JAN-90','Doctor', 2000,'Birth','no');

1 row created.

SQL> INSERT INTO staff VALUES ('S9','Priya','05-AUG-97','Nurse', 1000,'Birth','yes');

1 row created.

SQL> INSERT INTO staff VALUES ('S4','Krishna','28-MAR-87','Doctor', 4000,'Stomach','yes');

1 row created.

SQL> INSERT INTO staff VALUES ('S5','Jimmy','03-JAN-93','Doctor', 2500,'Therapy','yes');

1 row created.

SQL> INSERT INTO staff VALUES ('S6','Kurt','15-OCT-91','Doctor', 4000,'Heart','yes');

1 row created.

SQL> INSERT INTO staff VALUES ('S10','Prashant','19-JUN-93','Doctor', 2000,'ENT','yes');

1 row created.

SQL> INSERT INTO staff VALUES ('S11','Andy','18-JUN-92','Doctor', 2000,'brain','yes');

1 row created.

SQL> 
SQL> 
SQL> 
SQL> INSERT INTO appointmentinfo VALUES('P1','S1','A1');

1 row created.

SQL> INSERT INTO appointmentinfo VALUES('P2','S2','A2');

1 row created.

SQL> INSERT INTO appointmentinfo VALUES('P2','S8','A2');

1 row created.

SQL> INSERT INTO appointmentinfo VALUES('P3','S3','A3');

1 row created.

SQL> INSERT INTO appointmentinfo VALUES('P3','S9','A3');

1 row created.

SQL> INSERT INTO appointmentinfo VALUES('P4','S4','A4');

1 row created.

SQL> INSERT INTO appointmentinfo VALUES('P5','S5','A5');

1 row created.

SQL> INSERT INTO appointmentinfo VALUES('P6','S6','A6');

1 row created.

SQL> INSERT INTO appointmentinfo VALUES('P7','S10','A7');

1 row created.

SQL> 
SQL> 
SQL> INSERT INTO  S_Address VALUES ('SA1','Nepal','Province no.3','Kathmandu',39,'Thamel Street');

1 row created.

SQL> INSERT INTO  S_Address VALUES ('SA2','Nepal','Province no.3','Hetauda',14,'Hetauda chowk');

1 row created.

SQL> INSERT INTO  S_Address VALUES ('SA3','Nepal','Province no.3','Sindhuli',11,'Dada');

1 row created.

SQL> INSERT INTO  S_Address VALUES ('SA4','Nepal','Province no.2','Birgunj',145,'Ghadiarwa');

1 row created.

SQL> INSERT INTO  S_Address VALUES ('SA5','Nepal','Province no.1','Biratnagar',25,'Birat Chowk');

1 row created.

SQL> INSERT INTO  S_Address VALUES ('SA6','Nepal','Province no.5','Butwal',29,'Traffic Chowk');

1 row created.

SQL> INSERT INTO  S_Address VALUES ('SA7','Nepal','Gandaki Pradesh','Pokhara',50,'Pardi');

1 row created.

SQL> INSERT INTO  S_Address VALUES ('SA8','Nepal','Province no.3','Kathmandu',13,'Kalkhu Chowk');

1 row created.

SQL> INSERT INTO  S_Address VALUES ('SA9','Nepal','Province no.3','Kathmandu',46,'Star hospital');

1 row created.

SQL> INSERT INTO  S_Address VALUES ('SA10','Nepal','Gandaki Pradesh','Pokhara',150,'Phewa Tal');

1 row created.

SQL> 
SQL> 
SQL> INSERT INTO S_Contact VALUES ('SC1',9843678955,9863887552,'Prashant@gmail.com',22128888);

1 row created.

SQL> INSERT INTO S_Contact VALUES ('SC2',9844798755,9831897573,'Kiran@gmail.com',22345868);

1 row created.

SQL> INSERT INTO S_Contact VALUES ('SC3',9840758955,9818764554,'Preeti@gmail.com',25227898);

1 row created.

SQL> INSERT INTO S_Contact VALUES ('SC4',9823778955,9841787555,'Ayuesh@gmail.com',28225786);

1 row created.

SQL> INSERT INTO S_Contact VALUES ('SC5',9828978555,9811687556,'Priya@gmail.com',25628899);

1 row created.

SQL> INSERT INTO S_Contact VALUES ('SC6',9845656955,9851785557,'Krishna@gmail.com',21228814);

1 row created.

SQL> INSERT INTO S_Contact VALUES ('SC7',9827878855,9841687558,'Jimmy@gmail.com',21828457);

1 row created.

SQL> INSERT INTO S_Contact VALUES ('SC8',9851077895,9851073358,'Kurt@gmail.com',21428253);

1 row created.

SQL> INSERT INTO S_Contact VALUES ('SC9',9801033795,9801076358,'Prashant@gmail.com',23128654);

1 row created.

SQL> INSERT INTO S_Contact VALUES ('SC10',9819778855,986378755,'Andy@gmail.com',67228888);

1 row created.

SQL> 
SQL> 
SQL> INSERT INTO staffcontactinfo VALUES('S1','SA1','SC1');

1 row created.

SQL> INSERT INTO staffcontactinfo VALUES('S2','SA2','SC2');

1 row created.

SQL> INSERT INTO staffcontactinfo VALUES('S8','SA3','SC3');

1 row created.

SQL> INSERT INTO staffcontactinfo VALUES('S3','SA4','SC4');

1 row created.

SQL> INSERT INTO staffcontactinfo VALUES('S9','SA5','SC5');

1 row created.

SQL> INSERT INTO staffcontactinfo VALUES('S4','SA6','SC6');

1 row created.

SQL> INSERT INTO staffcontactinfo VALUES('S5','SA7','SC7');

1 row created.

SQL> INSERT INTO staffcontactinfo VALUES('S6','SA8','SC8');

1 row created.

SQL> INSERT INTO staffcontactinfo VALUES('S10','SA9','SC9');

1 row created.

SQL> INSERT INTO staffcontactinfo VALUES('S11','SA10','SC10');

1 row created.

SQL> select patient_id, p_name, type from patient where type='new' or type='regular';

PATIEN P_NAME                    TYPE                                           
------ ------------------------- --------                                       
P1     John                      new                                            
P2     Max                       new                                            
P3     Tom                       new                                            
P4     Jim                       regular                                        
P5     Natalia                   new                                            
P6     Pam                       new                                            
P7     Andy                      regular                                        

7 rows selected.

SQL> 
SQL> 
SQL> select patient.patient_id, patient.p_name, address.country, address.city, address.street,
  2  address.street_no, address.province from patient join
  3  contact_info on patient.patient_id= contact_info.patient_id join address on
  4  contact_info.a_id=address.a_id order by patient_id;

PATIEN P_NAME                    COUNTRY                                        
------ ------------------------- -------------------------                      
CITY                      STREET                     STREET_NO                  
------------------------- ------------------------- ----------                  
PROVINCE                                                                        
-------------------------                                                       
P1     John                      Nepal                                          
Kathmandu                 Jyatha Street                    139                  
Province no.3                                                                   
                                                                                
P2     Max                       Nepal                                          
Hetauda                   Hetauda City College               4                  
Province no.3                                                                   

PATIEN P_NAME                    COUNTRY                                        
------ ------------------------- -------------------------                      
CITY                      STREET                     STREET_NO                  
------------------------- ------------------------- ----------                  
PROVINCE                                                                        
-------------------------                                                       
                                                                                
P3     Tom                       Nepal                                          
Dolakha                   Kalinchok                         21                  
Province no.3                                                                   
                                                                                
P4     Jim                       Nepal                                          
Birgunj                   Shankaracharya Gate               45                  

PATIEN P_NAME                    COUNTRY                                        
------ ------------------------- -------------------------                      
CITY                      STREET                     STREET_NO                  
------------------------- ------------------------- ----------                  
PROVINCE                                                                        
-------------------------                                                       
Province no.2                                                                   
                                                                                
P5     Natalia                   Nepal                                          
Damak                     Damak Hospital                    65                  
Province no.1                                                                   
                                                                                
P6     Pam                       Nepal                                          

PATIEN P_NAME                    COUNTRY                                        
------ ------------------------- -------------------------                      
CITY                      STREET                     STREET_NO                  
------------------------- ------------------------- ----------                  
PROVINCE                                                                        
-------------------------                                                       
Butwal                    Siddha Baba Temple                39                  
Province no.5                                                                   
                                                                                
P7     Andy                      Nepal                                          
Pokhara                   Phewa Tal                        150                  
Gandaki Pradesh                                                                 
                                                                                

7 rows selected.

SQL> 
SQL> 
SQL> select staff.staff_id, staff.s_name, staff.category,staff.certified, appointment.Appointment_id , appointment.appointment_date,
  2  staff.staff_commission from staff join appointmentinfo
  3  on staff.staff_id =appointmentinfo.staff_id join appointment on appointmentinfo.Appointment_id = appointment.Appointment_id  where category='Doctor' and certified ='yes';

STAFF_ S_NAME                    CATEGORY CERTIFIE APPOIN APPOINTME             
------ ------------------------- -------- -------- ------ ---------             
STAFF_COMMISSION                                                                
----------------                                                                
S1     Prashant                  Doctor   yes      A1     15-JAN-19             
            2000                                                                
                                                                                
S2     Kiran                     Doctor   yes      A2     08-SEP-19             
            3000                                                                
                                                                                
S4     Krishna                   Doctor   yes      A4     07-SEP-19             
            4000                                                                
                                                                                

STAFF_ S_NAME                    CATEGORY CERTIFIE APPOIN APPOINTME             
------ ------------------------- -------- -------- ------ ---------             
STAFF_COMMISSION                                                                
----------------                                                                
S5     Jimmy                     Doctor   yes      A5     15-OCT-19             
            2500                                                                
                                                                                
S6     Kurt                      Doctor   yes      A6     16-FEB-19             
            4000                                                                
                                                                                
S10    Prashant                  Doctor   yes      A7     10-MAR-19             
            2000                                                                
                                                                                

6 rows selected.

SQL> 
SQL> 
SQL> SELECT staff.staff_id, staff.s_name, staff.category, staff.certified, appointment.appointment_id, appointment.appointment_date,
  2  staff.staff_commission from staff join appointmentinfo
  3  on staff.staff_id = appointmentinfo.staff_id join appointment on appointmentinfo.appointment_id = appointment.appointment_id
  4  where category= 'Doctor' and certified='no';

STAFF_ S_NAME                    CATEGORY CERTIFIE APPOIN APPOINTME             
------ ------------------------- -------- -------- ------ ---------             
STAFF_COMMISSION                                                                
----------------                                                                
S3     Ayuesh                    Doctor   no       A3     13-OCT-19             
            2000                                                                
                                                                                

SQL> 
SQL> 
SQL> 
SQL> select staff.staff_id, staff.s_name, appointment.Appointment_id , appointment.appointment_date
  2  from staff join appointmentinfo
  3  on staff.staff_id =appointmentinfo.staff_id join appointment on appointmentinfo.Appointment_id = appointment.Appointment_id where appointment_date='08-SEP-19';

STAFF_ S_NAME                    APPOIN APPOINTME                               
------ ------------------------- ------ ---------                               
S2     Kiran                     A2     08-SEP-19                               
S8     Preeti                    A2     08-SEP-19                               

SQL> 
SQL> 
SQL> 
SQL> select appointment.appointment_id, appointment.appointment_date, appointment.Time, ward .ward_name from appointment join ward on appointment.ward_no=ward.ward_no
  2  where ward.ward_name='Emergency';

APPOIN APPOINTME TIME     WARD_NAME                                             
------ --------- -------- ----------                                            
A8     11-MAR-19 10:35 AM Emergency                                             

SQL> 
SQL> 
SQL> 
SQL> select patient.patient_id, patient.p_name,appointment.Appointment_id, appointment.appointment_date
  2  from patient join appointmentinfo on patient.patient_id =appointmentinfo.patient_id join appointment on appointmentinfo.Appointment_id = appointment.Appointment_id where appointment_date='15-JAN-19';

PATIEN P_NAME                    APPOIN APPOINTME                               
------ ------------------------- ------ ---------                               
P1     John                      A1     15-JAN-19                               

SQL> spool off
