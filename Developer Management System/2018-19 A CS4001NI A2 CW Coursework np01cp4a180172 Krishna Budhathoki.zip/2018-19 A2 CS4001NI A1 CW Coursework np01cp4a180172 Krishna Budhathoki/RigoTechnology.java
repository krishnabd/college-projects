import java.awt.Container;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import java.io.IOException;
/**
 * This Class creates GUI for junior and senior developer which is linked with previous coursework
 * @author krishna budhathoki
 * @date 19th april, 2019
 */

/**
 * Creating  a class called as RigoTechnology
 */
public class RigoTechnology implements ActionListener
{
  JFrame frame;
  JLabel lblHead1,lblPlatformS,lblInterviewerS,lblWorkingHoursS,lblSalaryS,lblContractPeriod,lblSeDeveloper,lblJoiningDate,lblAdvanceSalary,lblStaffRoomNo,lblSDeveloperNo;
  JTextField txtPlatformS,txtInterviewerS,txtWorkingHoursS,txtSalaryS,txtContractPeriod,txtSeDeveloper,txtJoiningDate,txtAdvanceSalary,txtStaffRoomNo,txtSDeveloperNo;
  JButton btnAddS,btnHireS,btnTerminateS;
  JLabel lblHead2,lblPlatformJ,lblInterviewerJ,lblWorkingHoursJ,lblSalaryJ,lblAppointedBy,lblTerminationDate,lblDeveloperName,lblAppointedDate,lblSpecialization,lblJDeveloperNo;
  JTextField txtPlatformJ,txtInterviewerJ,txtWorkingHoursJ,txtSalaryJ,txtAppointedBy,txtTerminationDate,txtDeveloperName,txtAppointedDate,txtSpecialization,txtJDeveloperNo;
  JButton btnAddJ,btnAppointJ,btnDisplay,btnClear;
  ArrayList<Developer>developer;
  public RigoTechnology(){
     developer=new ArrayList<Developer>();
     gui(); 
  }
  public static void main(String[]args)
    {
     new RigoTechnology();
  }
  public void gui(){
       frame=new JFrame("RigoTechnology");
       frame.getContentPane().setBackground(new java.awt.Color(204, 166, 166));
       
        
       lblHead1=new JLabel("For Senior Developer");
       lblHead1.setBounds(120,10,300,30);
       lblHead1.setFont(new java.awt.Font("TimesRoman", java.awt.Font.BOLD, 20));
       frame.add(lblHead1);
        
       lblPlatformS=new JLabel("Platform:");
       lblPlatformS.setBounds(10,40,60,30);
       frame.add(lblPlatformS);
        
       txtPlatformS=new JTextField();
       txtPlatformS.setBounds(120,40,370,30);
       frame.add(txtPlatformS);
        
       lblInterviewerS=new JLabel("Interviewer Name:");
       lblInterviewerS.setBounds(10,80,115,30);
       frame.add(lblInterviewerS);
        
        
       txtInterviewerS=new JTextField();
       txtInterviewerS.setBounds(120,80,370,30);
       frame.add(txtInterviewerS);
        
       lblWorkingHoursS=new JLabel("Working Hours:");
       lblWorkingHoursS.setBounds(10,120,100,30);
       frame.add(lblWorkingHoursS);
        
       txtWorkingHoursS=new JTextField();
       txtWorkingHoursS.setBounds(120,120,100,30);
       frame.add(txtWorkingHoursS);
        
       lblSalaryS=new JLabel("Salary:");
       lblSalaryS.setBounds(230,120,50,30);
       frame.add(lblSalaryS);
        
       txtSalaryS=new JTextField();
       txtSalaryS.setBounds(290,120,200,30);
       frame.add(txtSalaryS);
        
       lblContractPeriod=new JLabel("Contract Period:");
       lblContractPeriod.setBounds(10,160,110,30);
       frame.add(lblContractPeriod);
        
       txtContractPeriod=new JTextField();
       txtContractPeriod.setBounds(120,160,100,30);
       frame.add(txtContractPeriod);
        
       btnAddS=new JButton("Add");
       btnAddS.setBounds(290,160,200,30);
       frame.add(btnAddS);
       btnAddS.addActionListener(this);
        
       lblSeDeveloper=new JLabel("Developer's Name:");
       lblSeDeveloper.setBounds(10,210,110,30);
       frame.add(lblSeDeveloper);
        
       txtSeDeveloper=new JTextField();
       txtSeDeveloper.setBounds(120,210,370,30);
       frame.add(txtSeDeveloper);
        
       lblAdvanceSalary=new JLabel("Advance Salary:");
       lblAdvanceSalary.setBounds(10,250,110,30);
       frame.add(lblAdvanceSalary);
        
       txtAdvanceSalary=new JTextField();
       txtAdvanceSalary.setBounds(120,250,100,30);
       frame.add(txtAdvanceSalary);
        
       lblJoiningDate=new JLabel("Joining Date:");
       lblJoiningDate.setBounds(230,250,200,30);
       frame.add(lblJoiningDate);
        
       txtJoiningDate=new JTextField();
       txtJoiningDate.setBounds(330,250,160,30);
       frame.add(txtJoiningDate);
        
       lblStaffRoomNo=new JLabel("Staff Room No:");
       lblStaffRoomNo.setBounds(10,290,100,30);
       frame.add(lblStaffRoomNo);
        
       txtStaffRoomNo=new JTextField();
       txtStaffRoomNo.setBounds(120,290,100,30);
       frame.add(txtStaffRoomNo);
        
       lblSDeveloperNo=new JLabel("Developer No:");
       lblSDeveloperNo.setBounds(230,290,100,30);
       frame.add(lblSDeveloperNo);
        
       txtSDeveloperNo=new JTextField();
       txtSDeveloperNo.setBounds(330,290,160,30);
       frame.add(txtSDeveloperNo);
        
       btnHireS=new JButton("Hire");
       btnHireS.setBounds(230,330,90,30);
       frame.add(btnHireS);
       btnHireS.addActionListener(this);
        
       btnTerminateS=new JButton("Terminate");
       btnTerminateS.setBounds(330,330,160,30);
       frame.add(btnTerminateS);
       btnTerminateS.addActionListener(this);
        
       lblHead2=new JLabel("For Junior Developer");
       lblHead2.setBounds(130,380,300,30);
       lblHead2.setFont(new java.awt.Font("TimesRoman", java.awt.Font.BOLD, 20));
       frame.add(lblHead2);
        
       lblPlatformJ=new JLabel("Platform:");
       lblPlatformJ.setBounds(10,410,60,30);
       frame.add(lblPlatformJ);
        
       txtPlatformJ=new JTextField();
       txtPlatformJ.setBounds(120,410,370,30);
       frame.add(txtPlatformJ);
        
       lblInterviewerJ=new JLabel("Interviewer Name:");
       lblInterviewerJ.setBounds(10,450,115,30);
       frame.add(lblInterviewerJ);
        
       txtInterviewerJ=new JTextField();
       txtInterviewerJ.setBounds(120,450,370,30);
       frame.add(txtInterviewerJ);
        
       lblWorkingHoursJ=new JLabel("Working Hours:");
       lblWorkingHoursJ.setBounds(10,490,100,30);
       frame.add(lblWorkingHoursJ);
        
       txtWorkingHoursJ=new JTextField();
       txtWorkingHoursJ.setBounds(120,490,100,30);
       frame.add(txtWorkingHoursJ);
        
       lblSalaryJ=new JLabel("Salary:");
       lblSalaryJ.setBounds(230,490,100,30);
       frame.add(lblSalaryJ);
        
       txtSalaryJ=new JTextField();
       txtSalaryJ.setBounds(330,490,160,30);
       frame.add(txtSalaryJ);
        
       lblAppointedBy=new JLabel("Appointed By:");
       lblAppointedBy.setBounds(10,530,90,30);
       frame.add(lblAppointedBy);
       
       txtAppointedBy=new JTextField();
       txtAppointedBy.setBounds(120,530,370,30);
       frame.add(txtAppointedBy);
        
       btnAddJ=new JButton("Add");
       btnAddJ.setBounds(330,570,160,30);
       frame.add(btnAddJ);
       btnAddJ.addActionListener(this);
        
       lblDeveloperName=new JLabel("Developer's Name:");
       lblDeveloperName.setBounds(10,630,115,30);
       frame.add(lblDeveloperName);
        
       txtDeveloperName=new JTextField();
       txtDeveloperName.setBounds(120,630,100,30);
       frame.add(txtDeveloperName);
        
       lblAppointedDate=new JLabel("Appointed Date:");
       lblAppointedDate.setBounds(230,630,100,30);
       frame.add(lblAppointedDate);
        
       txtAppointedDate=new JTextField();
       txtAppointedDate.setBounds(330,630,160,30);
       frame.add(txtAppointedDate);
        
       lblTerminationDate=new JLabel("Termination Date:");
       lblTerminationDate.setBounds(10,670,100,30);
       frame.add(lblTerminationDate);
        
       txtTerminationDate=new JTextField();
       txtTerminationDate.setBounds(120,670,100,30);
       frame.add(txtTerminationDate);
        
       lblJDeveloperNo=new JLabel("Developer No:");
       lblJDeveloperNo.setBounds(230,670,100,30);
       frame.add(lblJDeveloperNo);
        
       txtJDeveloperNo=new JTextField();
       txtJDeveloperNo.setBounds(330,670,160,30);
       frame.add(txtJDeveloperNo);
        
       lblSpecialization=new JLabel("Specialization:");
       lblSpecialization.setBounds(10,710,100,30);
       frame.add(lblSpecialization);
        
       txtSpecialization=new JTextField();
       txtSpecialization.setBounds(120,710,100,30);
       frame.add(txtSpecialization);
        
       btnAppointJ=new JButton("Appoint");
       btnAppointJ.setBounds(330,710,160,30);
       frame.add(btnAppointJ);
       btnAppointJ.addActionListener(this);
        
       btnDisplay=new JButton("Display");
       btnDisplay.setBounds(230,750,90,30);
       frame.add(btnDisplay);
       btnDisplay.addActionListener(this);
        
       btnClear=new JButton("Clear");
       btnClear.setBounds(330,750,160,30);
       frame.add(btnClear);
       btnClear.addActionListener(this);
       //adding in senior developer
        
       frame.setLayout(null);
       frame.setVisible(true);
       frame.setSize(530,850);
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   }    
   public void actionPerformed(ActionEvent ae)
    {if(ae.getSource().equals(btnAddS)){
          addSeniorDeveloper();
        }
     if(ae.getSource().equals(btnHireS)){
          HireDeveloper();
        }
     if(ae.getSource().equals(btnTerminateS)){
          terminated();
        }
     if(ae.getSource().equals(btnAddJ)){
          addJuniorDeveloper();
        }
     if(ae.getSource().equals(btnAppointJ)){
          AppointedJunior();
        }
     if(ae.getSource().equals(btnDisplay)){
          Display();
        }
     if(ae.getSource().equals(btnClear)){
          Clear();
        }
    
    } 
   public void addSeniorDeveloper(){
       //code for adding the information for senior Developer
    try{
           String platform=txtPlatformS.getText();
           String interviewer=txtInterviewerS.getText();
           String workinghour=txtWorkingHoursS.getText();
           String Salary=txtSalaryS.getText();
           String ContractPeriod=txtContractPeriod.getText();
           
           try{
               int workinghours=Integer.parseInt(workinghour);
               int contractPeriod=Integer.parseInt(ContractPeriod);
               int salary=Integer.parseInt(Salary);
               if(platform.equals("") || interviewer.equals("") || workinghour.equals("")|| Salary.equals("")|| ContractPeriod.equals("")){
                   JOptionPane.showMessageDialog(frame,"fill in all the field.please,fill all the fields!");
                   int length=developer.size();
                   length--;
                }
                else{
                    SeniorDeveloper hire=new SeniorDeveloper(platform,interviewer,workinghours,contractPeriod,salary);
                    developer.add(hire);
                    
                    JOptionPane.showMessageDialog(frame,"The Interview is going to be taken by " + interviewer + " for " + platform);
                }
            }
       catch(NullPointerException np)
           {
            JOptionPane.showMessageDialog(frame,np,"MESSAGE",JOptionPane.ERROR_MESSAGE);
            }
        
        catch(NumberFormatException nf)
        {
            JOptionPane.showMessageDialog(frame,nf,"MESSAGE",JOptionPane.ERROR_MESSAGE);
        }
    }
           catch(NumberFormatException nfe)
            {
             JOptionPane.showMessageDialog(frame,"Error in parsing string at addJuniorDeveloper()!!"+"\n"+nfe,"MESSAGE",JOptionPane.ERROR_MESSAGE);
            }
    
    }
  //hireing the  Senior Developer
    public void HireDeveloper()
    {
        try
        {
            String name = txtSeDeveloper.getText();
            String joiningDate = txtJoiningDate.getText();
            String staffRoomNo = txtStaffRoomNo.getText();
            int advSalary = Integer.parseInt(txtAdvanceSalary.getText());
            int devNo = Integer.parseInt(txtSDeveloperNo.getText());

            if(developer.size() < devNo)
            {
                JOptionPane.showMessageDialog(frame,"Sorry,there are "+developer.size()+" developers available in developer.");
            }
            else
            {
                if(name.equals("")||joiningDate.equals("")||staffRoomNo.equals(""))
                {
                    JOptionPane.showMessageDialog(frame,"Please fill all fields.","Error",JOptionPane.ERROR_MESSAGE);
                }
                else
                {
                    if(developer.get(devNo-1) instanceof SeniorDeveloper)
                    {
                        //converting type to senior dev
                        SeniorDeveloper objS = (SeniorDeveloper)developer.get(devNo-1);
                        //checking if developer is already appointed
                        if(objS.isAppointed() == false)
                        {
                            // calling hire senior dev method
                            objS.hire(name, joiningDate, advSalary,staffRoomNo);
                            JOptionPane.showMessageDialog(frame,"Successfully hired "+name+" as Senior Developer.");
                            //clearing fields
                            txtSeDeveloper.setText("");
                            txtJoiningDate.setText("");
                            txtStaffRoomNo.setText("");
                            txtAdvanceSalary.setText("");
                            txtJDeveloperNo.setText("");
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(frame,"A developer has already been hired.");    
                        }
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(frame,"Sorry,Developer isn't Senior Developer.");   
                    }
                }
            }
        }
    
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(frame,"Please fill all field with relevent data type.\n [advSalary and DevNo in whole number]","Error",JOptionPane.ERROR_MESSAGE);   
        }
    }
    public void terminated()
    
       
    {
       try{
      int developerNo = Integer.parseInt(txtSDeveloperNo.getText());
      if(developer.size()<developerNo){
        JOptionPane.showMessageDialog(frame,developer.size()+" developers available in developer.","Error",JOptionPane.ERROR_MESSAGE);
      }else{
        if(developer.get(developerNo-1) instanceof SeniorDeveloper){
          SeniorDeveloper objS = (SeniorDeveloper)developer.get(developerNo-1);
          if(objS.isAppointed() == true){
              if(objS.isTerminated() ==  false){
                  objS.contractTerminated();
                  JOptionPane.showMessageDialog(frame,"Developer is successfully terminated.");
                  txtSDeveloperNo.setText("");
            }else{
                  JOptionPane.showMessageDialog(frame,"Developer has already been terminated.","Error",JOptionPane.ERROR_MESSAGE);
            }
          }else{
                  JOptionPane.showMessageDialog(frame,"Developer hasn't been appointed.","Error",JOptionPane.ERROR_MESSAGE);              
          }          
        }else{
          JOptionPane.showMessageDialog(frame,"Developer isn't Senior developer.","Error",JOptionPane.ERROR_MESSAGE);
        }
      }
    }
    catch(Exception Event){
      JOptionPane.showMessageDialog(frame,"Please fill Developer No.(in whole number)","Error",JOptionPane.ERROR_MESSAGE);
    }
  }
    public void addJuniorDeveloper()
   {
      
       try
       {
       //code for adding the information for junior Developer
       String PlatformJ= txtPlatformJ.getText();
       String InterviewerJ =txtInterviewerJ.getText();
       String WorkingHoursJ =txtWorkingHoursJ.getText();
       String SalaryJ =txtSalaryJ.getText();
       String AppointedBy =txtAppointedBy.getText();
       String terminationDate=txtTerminationDate.getText();
       double SalaryJe=0.0;
       try
       {
       int WorkingHours=Integer.parseInt(txtWorkingHoursJ.getText());
       SalaryJe=Double.parseDouble(txtSalaryJ.getText());
       
    
       if (PlatformJ.equals("") || InterviewerJ.equals("") || WorkingHoursJ.equals(" ") || SalaryJ.equals("") ||AppointedBy.equals("") )
    
       
       {
           JOptionPane.showMessageDialog(frame,"You should fill in all the fields. Please, fill all the fields!");
           int length =developer.size();
           
       }
       else
       {
           if ( SalaryJe<=0)
           {
               JOptionPane.showMessageDialog(frame,"Please! Enter the valid number","MESSAGE",JOptionPane.ERROR_MESSAGE);
            }
           else{
               JuniorDeveloper hireJ= new JuniorDeveloper(PlatformJ,InterviewerJ,WorkingHours,SalaryJe,AppointedBy,terminationDate);
               developer.add(hireJ);
               JOptionPane.showMessageDialog(frame,"For appointing the junior developer"+"\n"+"Platform:"+" "+PlatformJ+"\n"+"Interviewer Name:"+" "+InterviewerJ+"\n"+"Working Hour:"+" "+WorkingHoursJ +"\n"+"Salary:"+" "+SalaryJ +"\n"+"Appointed By::"+" "+AppointedBy,"MESSAGE",JOptionPane.INFORMATION_MESSAGE);
           }
       }
       }
       catch(NullPointerException np)
       {
            JOptionPane.showMessageDialog(frame,np,"MESSAGE",JOptionPane.ERROR_MESSAGE);
       }

       catch(NumberFormatException nf)
       {
            JOptionPane.showMessageDialog(frame,nf,"MESSAGE",JOptionPane.ERROR_MESSAGE);
       }
            }
       catch(NumberFormatException nfe)
       {
              JOptionPane.showMessageDialog(frame,"Error in parsing string at addGenToRent()!!"+"\n"+nfe,"MESSAGE",JOptionPane.ERROR_MESSAGE);
            }
        
                txtPlatformJ.setText("");
                txtInterviewerJ.setText("");
                txtWorkingHoursJ.setText("");
                txtSalaryJ.setText("");
                txtAppointedBy.setText("");
   }
   public void AppointedJunior()
    {
        try
        {
            String name = txtDeveloperName.getText();
            String appointedDate = txtAppointedDate.getText();
            String terminationDate = txtTerminationDate.getText();
            String specialization = txtSpecialization.getText();
            int devNo = Integer.parseInt(txtJDeveloperNo.getText());
            if(developer.size() < devNo)
            {
                JOptionPane.showMessageDialog(frame,"Sorry,there are "+developer.size()+" developers available in developer.");
            }
            else
            {
                if(name.equals("")||appointedDate.equals("")||terminationDate.equals("")||specialization.equals(""))
                {
                    JOptionPane.showMessageDialog(frame,"Please fill all fields.","Error",JOptionPane.ERROR_MESSAGE);
                }
                else
                {
                    if(developer.get(devNo-1) instanceof JuniorDeveloper)
                    {
                        //changing type to junior developer
                        JuniorDeveloper objJ = (JuniorDeveloper)developer.get(devNo-1);
                        // checking if developer is already got joined
                        if(objJ.isJoined() == false)
                        {
                            //calling appoint junior developer 
                            objJ.appointDeveloper(name,appointedDate, terminationDate,specialization);
                            JOptionPane.showMessageDialog(frame,name+"is successfully appointed as Junior Developer.");
                            //clearing fields
                            txtDeveloperName.setText("");
                            txtAppointedDate.setText("");
                            txtTerminationDate.setText("");
                            txtSpecialization.setText("");
                            txtJDeveloperNo.setText("");
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(frame,"A developer has already Joined.");    
                        }
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(frame,"Sorry,Developer isn't Junior Developer.");   
                    }
                }
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(frame,"Please fill all field with relevent data type.\n [DevNo in whole number]","Error",JOptionPane.ERROR_MESSAGE);           
        }
    }
    public void Display() {
        //method for displaying all the information for senior and junior developer
        for (Developer d: developer) {
            if(d instanceof SeniorDeveloper) {
                System.out.println("         Senior Developer     ");
                SeniorDeveloper dis = (SeniorDeveloper) d;
                dis.display();
                System.out.println("                                    ");
            } 
            if(d instanceof JuniorDeveloper) {
                System.out.println("        Junior Developer      ");
                JuniorDeveloper dis1 = (JuniorDeveloper) d;
                dis1.display();
                System.out.println("                                    ");
            }
        }
    }
    public void Clear(){
        //code for clearing all the text fields
        txtPlatformJ.setText("");
        txtInterviewerJ.setText("");
        txtWorkingHoursJ.setText("");
        txtSalaryJ.setText("");
        txtAppointedBy.setText("");
        txtTerminationDate.setText("");
        txtDeveloperName.setText("");
        txtAppointedDate.setText("");
        txtSpecialization.setText("");
        txtJDeveloperNo.setText("");
        txtPlatformS.setText("");
        txtInterviewerS.setText("");
        txtWorkingHoursS.setText("");
        txtSalaryS.setText("");
        txtContractPeriod.setText("");
        txtSeDeveloper.setText("");
        txtJoiningDate.setText("");
        txtAdvanceSalary.setText("");
        txtStaffRoomNo.setText("");
        txtSDeveloperNo.setText("");
    }
}

 
    