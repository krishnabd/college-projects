public class Developer{
   String platform;
   String interviewername;
   int workinghours;
   String developername;
   //initializing the attributes
   public Developer(String platform,String interviewername,int workinghours){
       this.platform=platform;
       this.interviewername=interviewername;
       this.workinghours=workinghours;
       this.developername="";
   }
   //using each corresponding accessor method for accessing each method
   public String getDeveloperName(){
    return developername;
    }
    public String getplatform(){
       return platform;
   }
   public String getInterviewername(){
       return interviewername;
   }
   public int getworkinghours(){
       return workinghours;
   }
   public void setdevelopername(String developername){
       this.developername=developername;
   }
   //display method
   public void display(){
      System.out.println("Platform =" +getplatform());
      System.out.println("Interviewername =" +getInterviewername());
      System.out.println("Workinghours =" +getworkinghours());
      if(!developername.equals("")){
            System.out.println("Developername =" +developername);
   }
   }
}