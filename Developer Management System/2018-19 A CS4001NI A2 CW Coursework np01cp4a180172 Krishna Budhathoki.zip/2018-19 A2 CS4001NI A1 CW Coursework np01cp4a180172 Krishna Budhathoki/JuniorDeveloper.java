public class  JuniorDeveloper extends Developer{
    double salary;
    String appointedDate;
    String evaluationDate;
    String terminationDate;
    String specialization;
    String appointedBy;
    boolean joined;
    //initializing the attributes
    public JuniorDeveloper(String platform,String interviewername,int workinghours,double salary,String appointedBy,String terminationDate){
        super(platform,interviewername,workinghours);
        this.appointedBy=appointedBy;
        this.terminationDate=terminationDate;
        this.salary = salary;
        appointedDate="";
        evaluationDate="";
        specialization="";
        joined=false;
    }
    //using each corresponding accessor method for accessing each method
    public double getSalary(){
        return salary;
    }
    public String getAppointedDate(){
    return appointedDate;
    }
    public String getEvaluationDate(){
    return evaluationDate;
    }
    public String getTerminationDate(){
    return terminationDate;
    }
    public String getSpecialization(){
    return specialization;
    }
    public String getAppointedBy(){
    return appointedBy;
    }
    public boolean isJoined(){
    return joined;
    }
     public void setSalary(double salary){
      if (joined==false){
        this.salary=salary;
        System.out.println("you salary is changedd");
    }
    else if (joined==true){
        System.out.println("it is not possible to change the salary");
    }
    }
    public void appointDeveloper(String developername,String appointedDate,String terminationDate,String specialization){
        if (joined==false){
           setdevelopername(developername);
           this.appointedDate = appointedDate;
           this.terminationDate = terminationDate;
           this.specialization = specialization;
           joined = true;
           System.out.println("Developer is appointed.");
        }
        else if(joined==true){
            System.out.println("you are already joined");
        }  
    }
    //method to display
    public void display(){
    super.display();
    if (joined==true){
        System.out.println("appointedDate="+appointedDate);
        System.out.println("evaluationPeriod="+evaluationDate);
        System.out.println("terminationDate="+terminationDate);
        System.out.println("developerSalary="+salary);
        System.out.println("developerSpecialization="+specialization);
        System.out.println("appointedBy="+appointedBy);
    }
    }
}