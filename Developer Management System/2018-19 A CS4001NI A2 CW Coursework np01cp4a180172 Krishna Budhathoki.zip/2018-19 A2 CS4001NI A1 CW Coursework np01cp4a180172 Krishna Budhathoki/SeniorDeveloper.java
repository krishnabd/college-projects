public class SeniorDeveloper extends Developer{
    int salary;
    String joiningDate;
    String staffRoomNumber;
    int contractPeriod;
    float advanceSalary;
    boolean appointed;
    boolean terminated;
    //initializing the attributes
    public SeniorDeveloper(String platform,String interviewername,int workinghours,int salary,int contractPeriod){
        super(platform,interviewername,workinghours);
        this.salary=salary;
        this.workinghours=workinghours;
        this.contractPeriod = contractPeriod;
        joiningDate="";
        staffRoomNumber="";
        advanceSalary=0f;
        appointed=false;
        terminated=false;
    }
    //using each corresponding accessor method for accessing each method
    public float getSalary(){
        return salary;
    }
    public String getJoiningDate(){
        return joiningDate;
    }
    public String getStaffRoomNumber(){
        return staffRoomNumber;
    }
    public int getContractPeriod(){
        return contractPeriod;
    }
    public float getAdvanceSalary(){
        return advanceSalary;
    }
    public boolean isAppointed(){
        return appointed;
    }
    public boolean isTerminated(){
        return terminated;
    }
    public void setSalary(int salary){
        this.salary=salary;
    }
    public void setContractPeriod(int contractPeriod){
        this.contractPeriod=contractPeriod;
    }
    // method to hire developer
    public void hire(String developername,String joiningDate,float advanceSalary,String staffRoomNumber){
        if (appointed==true){
            System.out.println("Developer is already appointed.");
            System.out.println("developer name= "+developername);
            System.out.println("room no= "+getStaffRoomNumber());
        }
        else if (appointed==false){
            setdevelopername(developername);
            this.joiningDate=joiningDate;
            this.staffRoomNumber=staffRoomNumber;
            this.advanceSalary=advanceSalary;
            appointed=true;
            terminated=false;
            System.out.println("Developer is now hired.");
        }
    }
    public void contractTerminated(){
        if (terminated==true){
            System.out.println("you are already terminated");
        }
        else if (terminated==false){
            this.terminated=true;
            setdevelopername("");
            joiningDate="";
            advanceSalary=0.0f;
            appointed=false;
            terminated=true;
            System.out.println("Developer is now terminated.");
        }
    }
    public void print(){
        System.out.println("platform= "+getplatform());
        System.out.println("interviewersName= "+getInterviewername());
        System.out.println("salary= "+getSalary());
    }
    //method to display
    public void display(){
      super.display();
      if (appointed==true){
        System.out.println("termination= "+isTerminated());
        System.out.println("joindate= "+getJoiningDate());
        System.out.println("advancesalary= "+getAdvanceSalary());
        }
    }
}